from math_stuff import MathStuff

def run():
  print("Hello World")
  mathStuff = MathStuff()
  print(mathStuff.square(5))
    
if __name__ == "__main__":
  run()
