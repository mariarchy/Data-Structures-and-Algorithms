#!/bin/bash

python runner.py